def the_flying_circus():
    if 7 > 5 and 7 < 9:
        return True
    elif 7 < 3:
        return False
    else:
        return False
print the_flying_circus()
