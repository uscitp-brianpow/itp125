#MYPROJECT.PY
#BRIAN POWERS
#README
#THIS PROGRAM IS WRITTEN TO CREATE A VOICEMAIL GREETING FROM THE OLD SPICE
#VOICEMAIL GENERATOR CLIP THAT WAS PUBLISHED ON YOUTUBE. THE PROGRAM WILL ASK
#THE USER FOR A VARIETY OF INPUT INFORMATION AND EVENTUALLY FORMULATE THIS
#GREETING BASED ON USER CHOICES. THE PROGRAM WILL ALSO CREATE A TEXT FILE
#CONTAINING THE LIST OF MP3 CLIPS THAT WERE INCLUDED IN THE FINAL VERSION OF THE VOICEMAIL.

#THE FOLLOWING FLAGS CAN BE USED IN THE TERMINAL WINDOW TO RUN THE PYTHON PROGRAM
#AND CUSTOMIZE OPTIONS:

#-n PHONE NUMBER (10 DIGITS)
#-g GENDER (M OR F)
#-r REASONS (1-5)
#-e ENDINGS (1-5)
#-o NAME OF OUTPUT FILE. FOR EXAMPLE, INPUT GREETING AND THE FILE WILL BE
#CALLED GREETING.MP3

#THIS PROGRAM HAS THE ABILITY TO DISTINGUISH BETWEEN WINDOWS AND MAC/LINUX
#OPERATING SYSTEMS, BUT WAS NOT ABLE TO BE TESTED ON A WINDOWS SYSTEM. AS
#A RESULT, THE PROGRAMS EFFICACY ON A WINDOWS COMPUTER CAN NOT BE VERIFIED.

#Import libraries
import urllib2
import subprocess
import argparse
#Parsing list created
parser = argparse.ArgumentParser()
parser.add_argument('-n', action='store', dest='phone_number_input',
                    help='Store a simple value')
parser.add_argument('-g', action='store', dest='gender',
                    help='Store a simple value')
parser.add_argument('-r', action='store', dest='reasons',
                    help='Store a simple value')
parser.add_argument('-e', action='store', dest='endings',
                    help='Store a simple value')
parser.add_argument('-o', action='store', dest='output_name',
                    help='Store a simple value')
results = parser.parse_args()

#Detect operating system
from sys import platform as _platform

if _platform == "Darwin" or _platform == "darwin":
    os = "1";
elif _platform == "win32":
    os = "2";
else:
    os = "2";

#Initiates while loop in case starting over is necessary
xx = 0;
while xx==0:
    #Male or female choice
    gender = results.gender
    if gender:
        if gender=='m':
            gender = 'm'
        elif gender=='f':
            gender = 'f'
        elif (gender!='1') and (gender!='2'):
            x = 0
            print "Error, try again"
            while x==0:
                gender = raw_input("Enter'1' for male or '2' for female:")
                if (gender!='1') and (gender!='2'):
                    x = 0
                else:
                    x = 1
            if gender=='1':
                gender = 'm'
            elif gender=='2':
                gender = 'f'
    else:
        x = 0
        while x==0:
            gender = raw_input("Enter'1' for male or '2' for female:")
            if (gender!='1') and (gender!='2'):
                print "Error try again"
                x = 0
            else:
                x = 1
        if gender=='1':
            gender = 'm'
        elif gender=='2':
            gender = 'f'

    #Phone number entry
    number = '';
    number = results.phone_number_input;
    if number:
        number = number
    else:
        number = raw_input("Enter a phone number number: ")
    #This part changes the number to a 10 digit format, without dashes or other
    #characters.
    length = len(number)
    for n in range(0, (len(number)-1)):
        try:
            val = int(number[n])
        except ValueError:
            number = number.replace(number[n], "x")
    number = number.replace("x", "")


    #This section gets the mp3 files for the numbers.
    text = ' '
    for n in range(0, 10):
        if number[n]=="1":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/1.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 1.mp3'
        elif number[n]=="2":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/2.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 2.mp3'
        elif number[n]=="3":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/3.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 3.mp3'
        elif number[n]=="4":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/4.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 4.mp3'
        elif number[n]=="5":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/5.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 5.mp3'
        elif number[n]=="6":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/6.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 6.mp3'
        elif number[n]=="7":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/7.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 7.mp3'
        elif number[n]=="8":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/8.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 8.mp3'
        elif number[n]=="9":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/9.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 9.mp3'
        elif number[n]=="0":
            mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/0.mp3")
            with open('num%s.mp3' % n ,'wb') as output:
              output.write(mp3file.read())
            text = text + ' 0.mp3'

    #Male options and voicemail
    if gender =='m':
        mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-b1-hello.mp3")
        with open('intro.mp3','wb') as output:
          output.write(mp3file.read())

        mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-b2-have_dialed.mp3")
        with open('second.mp3','wb') as output:
          output.write(mp3file.read())

        mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r0-cannot_come_to_phone.mp3")
        with open('bridge.mp3','wb') as output:
          output.write(mp3file.read())
        text = ' m-b1-hello.mp3 m-r0-cannot_come_to_phone.mp3' + text

        #Reasons for male

        maleReason = results.reasons
        if maleReason:
                maleReason = maleReason
        else:
                print 'Enter number (or numbers) of desired reason(s)'
                print '[1] Building an orphanage for children with their bare hands'
                print '[2] Cracking walnuts with their man mind'
                print '[3] Polishing their monocle smile'
                print '[4] Ripping out mass loads of weights'
                maleReason = raw_input('Enter number(s): ')

        #condenses number choices
        length_mr = len(maleReason)
        for n in range(0, (len(maleReason)-1)):
            try:
                val = int(maleReason[n])
            except ValueError:
                maleReason = maleReason.replace(maleReason[n], "x")
        maleReason = maleReason.replace("x", "")


        #Ensures that proper number and type of choices are made, or starts over
        print len(maleReason)
        x = 0;
        while x == 0:
            l = 0;
            for n in range(0, len(maleReason)):
                if (maleReason[n]=='1'):
                    l = l + 1
                elif (maleReason[n]=='2'):
                    l = l + 1
                elif (maleReason[n]=='3'):
                    l = l + 1
                elif (maleReason[n]=='4'):
                    l = l + 1
            if l==len(maleReason):
                x = 1;
            else:
                print 'Error entering reasons'
                print 'Enter number (or numbers) of desired reason(s)'
                print '[1] Building an orphanage for children with their bare hands'
                print '[2] Cracking walnuts with their man mind'
                print '[3] Polishing their monocle smile'
                print '[4] Ripping out mass loads of weights'
                maleReason = raw_input('Enter number(s): ')


        #Assigns mp3 files
        for n in range(0, len(maleReason)):
            if maleReason[n]=="1":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r1-building.mp3")
                with open('mr%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' m-r1-building.mp3'
            elif maleReason[n]=="2":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r2-cracking_walnuts.mp3")
                with open('mr%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' m-r2-cracking_walnuts.mp3'
            elif maleReason[n]=="3":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r3-polishing_monocole.mp3")
                with open('mr%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' m-r3-polishing_monocole.mp3'
            elif maleReason[n]=="4":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r4-ripping_weights.mp3")
                with open('mr%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' m-r4-ripping_weights.mp3'

        #Determines how many files to merge and merges in to mreasons,mp3
        if len(maleReason)==1:
            if os=="1":
                x = subprocess.Popen('cat mr0.mp3 > mreasons.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy /b mr0.mp3 c:\mreasons.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                x = subprocess.Popen('rm mr0.mp3', shell=True, )
            else:
                x = subprocess.Popen('del mr0.mp3', shell=True, )
        elif len(maleReason)==2:
            if os=="1":
                x = subprocess.Popen('cat mr0.mp3 mr1.mp3 > mreasons.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy /b mr0.mp3 + mr1.mp3 c:\mreasons.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                x = subprocess.Popen('rm mr0.mp3 mr1.mp3', shell=True, )
            else:
                x = subprocess.Popen('del mr0.mp3 + mr1.mp3', shell=True, )
        elif len(maleReason)==3:
            if os=="1":
                x = subprocess.Popen('cat mr0.mp3 mr1.mp3 mr2.mp3 > mreasons.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy /b mr0.mp3 + mr1.mp3 + mr2.mp3 c:\mreasons.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                x = subprocess.Popen('rm mr0.mp3 mr1.mp3 mr2.mp3', shell=True, )
            else:
                x = subprocess.Popen('del mr0.mp3 + mr1.mp3 + mr2.mp3', shell=True, )
        elif len(maleReason)==4:
            if os=="1":
                x = subprocess.Popen('cat mr0.mp3 mr1.mp3 mr2.mp3 mr3.mp3 > mreasons.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy /b mr0.mp3 + mr1.mp3 + mr2.mp3 + mr3.mp3  c:\mreasons.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                x = subprocess.Popen('rm mr0.mp3 mr1.mp3 mr2.mp3 mr3.mp3', shell=True, )
            else:
                x = subprocess.Popen('del mr0.mp3 + mr1.mp3 + mr2.mp3 + mr3.mp3', shell=True, )

        #Gets the "leave a message" part
        mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-leave_a_message.mp3")
        with open('vm.mp3','wb') as output:
          output.write(mp3file.read())
        text = text + ' m-leave_a_message.mp3'

        #Endings for male
        maleEnding = results.endings
        if maleEnding:
                maleEnding = maleEnding
        else:
                print 'Enter number (or numbers) of desired endings(s)'
                print '[1] I''m on a horse'
                print '[2] Jingle'
                print '[3] I''m on a phone'
                print '[4] Swan dive'
                print '[5] Please leave a voicemail'
                maleEnding = raw_input('Enter number(s): ')

        #condenses number choices
        length_me = len(maleEnding)
        for n in range(0, (len(maleEnding)-1)):
            try:
                val = int(maleEnding[n])
            except ValueError:
                maleEnding = maleEnding.replace(maleEnding[n], "x")
        maleEnding = maleEnding.replace("x", "")

        #Ensures that correct number and type of choices are made
        print len(maleEnding)
        x = 0;
        while x == 0:
            l = 0;
            for n in range(0, len(maleEnding)):
                if (maleEnding[n]=='1'):
                    l = l + 1
                elif (maleEnding[n]=='2'):
                    l = l + 1
                elif (maleEnding[n]=='3'):
                    l = l + 1
                elif (maleEnding[n]=='4'):
                    l = l + 1
                elif (maleEnding[n]=='5'):
                    l = l + 1
            if l==len(maleEnding):
                x = 1;
            else:
                print 'Error entering endings'
                print 'Enter number (or numbers) of desired endings(s)'
                print '[1] I''m on a horse'
                print '[2] Jingle'
                print '[3] I''m on a phone'
                print '[4] Swan dive'
                print '[5] Please leave a voicemail'
                maleEnding = raw_input('Enter number(s): ')

        #Assigns mp3 files
        for n in range(0, len(maleEnding)):
            if maleEnding[n]=="1":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e1-horse.mp3")
                with open('me%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' m-e1-horse.mp3'
            elif maleEnding[n]=="2":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e2-jingle.mp3")
                with open('me%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' m-e2-jingle.mp3'
            elif maleEnding[n]=="3":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e3-on_phone.mp3")
                with open('me%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' m-e3-on_phone.mp3'
            elif maleEnding[n]=="4":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e4-swan_dive.mp3")
                with open('me%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' m-e4-swan_dive.mp3'
            elif maleEnding[n]=="5":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e5-voicemail.mp3")
                with open('me%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' m-e5-voicemail.mp3'

        #Determines how many files to merge and merges in to mendings,mp3
        if len(maleEnding)==1:
            if os=="1":
                x = subprocess.Popen('cat me0.mp3 > mendings.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy /b me0.mp3 c:\mendings.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm me0.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del me0.mp3', shell=True, )
        elif len(maleEnding)==2:
            if os=="1":
                x = subprocess.Popen('cat me0.mp3 me1.mp3 > mendings.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy /b me0.mp3 + me1.mp3 c:\mendings.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm me0.mp3 me1.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del me0.mp3 + me1.mp3', shell=True, )
        elif len(maleEnding)==3:
            if os=="1":
                x = subprocess.Popen('cat me0.mp3 me1.mp3 me2.mp3 > mendings.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy /b me0.mp3 + me1.mp3 + me2.mp3 c:\mendings.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm me0.mp3 me1.mp3 me2.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del me0.mp3 + me1.mp3 + me2.mp3', shell=True, )
        elif len(maleEnding)==4:
            if os=="1":
                x = subprocess.Popen('cat me0.mp3 me1.mp3 me2.mp3 me3.mp3 > mendings.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy /b me0.mp3 + me1.mp3 + me2.mp3 + me3.mp3 c:\mendings.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm me0.mp3 me1.mp3 me2.mp3 me3.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del me0.mp3 + me1.mp3 + me2.mp3 + me3.mp3', shell=True, )
        elif len(maleEnding)==5:
            if os=="1":
                x = subprocess.Popen('cat me0.mp3 me1.mp3 me2.mp3 me3.mp3 me4.mp3 > mendings.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy /b me0.mp3 + me1.mp3 + me2.mp3 + me3.mp3 + me4.mp3  c:\mendings.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm me0.mp3 me1.mp3 me2.mp3 me3.mp3 me4.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del me0.mp3 + me1.mp3 + me2.mp3 + me3.mp3 + me4.mp3', shell=True, )

        #Gets output filename
        output = results.output_name
        if output:
            output = output
        else:
            output = raw_input('Enter desired filename with no spaces.')
        #Prints names of files that will be merged
        print text
        choice = raw_input('Press 1 to create this message, or press 2 to start over')
        if choice=='1':
            xx = 1;
        elif choice=='2':
            xx=0;

    #FEMALE SECTION
    elif gender =='f':
        mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-b1-hello_caller.mp3")
        with open('intro.mp3','wb') as output:
          output.write(mp3file.read())
        mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-b2-lady_at.mp3")
        with open('second.mp3','wb') as output:
          output.write(mp3file.read())
        mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r0.1-unable_to_take_call.mp3")
        with open('bridge1.mp3','wb') as output:
          output.write(mp3file.read())
        mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r0.2-she_is_busy.mp3")
        with open('bridge2.mp3','wb') as output:
          output.write(mp3file.read())
        text = ' f-b1-hello_caller.mp3 f-b2-lady_at.mp3 f-r0.1-unable_to_take_call.mp3 f-r0.2-she_is_busy.mp3' + text
        #Reasons for female
        femaleReason = results.reasons
        if femaleReason:
                femaleReason = femaleReason
        else:
                print 'Enter number (or numbers) of desired reason(s)'
                print '[1] Ingesting my delicious Old Spice man smell'
                print '[2] Listening to me reading romantic poetry while I make a bouquet of paper flowers from each read page'
                print '[3] Lobster dinner'
                print '[4] Being serenaded on the Moon with a view of the Earth'
                print '[5] Riding on horseback'
                femaleReason = raw_input('Enter number(s): ')

        #condenses number choices
        length_fr = len(femaleReason)
        for n in range(0, (len(femaleReason)-1)):
            try:
                val = int(femaleReason[n])
            except ValueError:
                femaleReason = femaleReason.replace(femaleReason[n], "x")
        femaleReason = femaleReason.replace("x", "")

        #Finds error and changes format of entry
        print len(femaleReason)
        x = 0;
        while x == 0:
            l = 0;
            for n in range(0, len(femaleReason)):
                if (femaleReason[n]=='1'):
                    l = l + 1
                elif (femaleReason[n]=='2'):
                    l = l + 1
                elif (femaleReason[n]=='3'):
                    l = l + 1
                elif (femaleReason[n]=='4'):
                    l = l + 1
                elif (femaleReason[n]=='5'):
                    l = l + 1
            if l==len(femaleReason):
                x = 1;
            else:
                print 'Error entering reasons'
                print 'Enter number (or numbers) of desired reason(s)'
                print '[1] Ingesting my delicious Old Spice man smell'
                print '[2] Listening to me reading romantic poetry while I make a bouquet of paper flowers from each read page'
                print '[3] Lobster dinner'
                print '[4] Being serenaded on the Moon with a view of the Earth'
                print '[5] Riding on horseback'
                femaleReason = raw_input('Enter number(s): ')

        #Assigns mp3 files
        for n in range(0, len(femaleReason)):
            if femaleReason[n]=="1":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r1-ingesting_old_spice.mp3")
                with open('fr%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' f-r1-ingesting_old_spice.mp3'
            elif femaleReason[n]=="2":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r2-listening_to_reading.mp3")
                with open('fr%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' f-r2-listening_to_reading.mp3'
            elif femaleReason[n]=="3":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r3-lobster_dinner.mp3")
                with open('fr%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' f-r3-lobster_dinner.mp3'
            elif femaleReason[n]=="4":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r4-moon_kiss.mp3")
                with open('fr%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' f-r4-moon_kiss.mp3'
            elif femaleReason[n]=="5":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r5-riding_a_horse.mp3")
                with open('fr%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' f-r5-riding_a_horse.mp3'

            #Determines how many files to merge and merges in to freasons.mp3
        if len(femaleReason)==1:
            if os=="1":
                x = subprocess.Popen('cat fr0.mp3 > freasons.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy fr0.mp3 c:\freasons.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm fr0.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del fr0.mp3', shell=True, )
        elif len(femaleReason)==2:
            if os=="1":
                x = subprocess.Popen('cat fr0.mp3 fr1.mp3  > freasons.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy fr0.mp3 + fr1.mp3 c:\freasons.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm fr0.mp3 fr1.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del fr0.mp3 + fr1.mp3', shell=True, )
        elif len(femaleReason)==3:
            if os=="1":
                x = subprocess.Popen('cat fr0.mp3 fr1.mp3 fr2.mp3 > freasons.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy fr0.mp3 + fr1.mp3 + fr2.mp3 c:\freasons.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm fr0.mp3 fr1.mp3 fr2.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del fr0.mp3 + fr1.mp3 + fr2.mp3', shell=True, )
        elif len(femaleReason)==4:
            if os=="1":
                x = subprocess.Popen('cat fr0.mp3 fr1.mp3 fr2.mp3 fr3.mp3 > freasons.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy fr0.mp3 + fr1.mp3 + fr2.mp3 + fr3.mp3 c:\freasons.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm fr0.mp3 fr1.mp3 fr2.mp3 fr3.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del fr0.mp3 + fr1.mp3 + fr2.mp3 + fr3.mp3', shell=True, )
        elif len(femaleReason)==5:
            if os=="1":
                x = subprocess.Popen('cat fr0.mp3 fr1.mp3 fr2.mp3 fr3.mp3 fr4.mp3 > freasons.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy fr0.mp3 + fr1.mp3 + fr2.mp3 + fr3.mp3 + fr4.mp3 c:\freasons.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm fr0.mp3 fr1.mp3 fr2.mp3 fr3.mp3 fr4.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del fr0.mp3 + fr1.mp3 + fr2.mp3 + fr3.mp3 + fr4.mp3', shell=True, )

        #Endings for female
        femaleEnding = results.endings
        if femaleEnding:
                femaleEnding = femaleEnding
        else:
                print 'Enter number (or numbers) of desired endings(s)'
                print '[1] She will get back to you'
                print '[2] Thanks for calling'
                femaleEnding = raw_input('Enter number(s): ')

        #condenses number choices
        length_fe = len(femaleEnding)
        for n in range(0, (len(femaleEnding)-1)):
            try:
                val = int(femaleEnding[n])
            except ValueError:
                femaleEnding = femaleEnding.replace(femaleEnding[n], "x")
        femaleEnding = femaleEnding.replace("x", "")

        #Finds error and changes format of entry
        print len(femaleEnding)
        x = 0;
        while x == 0:
            l = 0;
            for n in range(0, len(femaleEnding)):
                if (femaleEnding[n]=='1'):
                    l = l + 1
                elif (femaleEnding[n]=='2'):
                    l = l + 1
            if l==len(femaleEnding):
                x = 1;
            else:
                print 'Error entering endings'
                print 'Enter number (or numbers) of desired endings(s)'
                print '[1] She will get back to you'
                print '[2] Thanks for calling'
                femaleEnding = raw_input('Enter number(s): ')

                #assings mp3 files
        for n in range(0, len(femaleEnding)):
            if femaleEnding[n]=="1":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-e1-she_will_get_back_to_you.mp3")
                with open('fe%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' f-e1-she_will_get_back_to_you.mp3'
            elif femaleEnding[n]=="2":
                mp3file = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-e2-thanks_for_calling.mp3")
                with open('fe%s.mp3' % n ,'wb') as output:
                  output.write(mp3file.read())
                text = text + ' f-e2-thanks_for_calling.mp3'

        if len(femaleEnding)==1:
            if os=="1":
                x = subprocess.Popen('cat fe0.mp3 > fendings.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy fe0.mp3 c:\fendings.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm fe0.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del fe0.mp3', shell=True, )
        elif len(femaleEnding)==2:
            if os=="1":
                x = subprocess.Popen('cat fe0.mp3 fe1.mp3 > fendings.mp3', shell=True, )
            else:
                x = subprocess.Popen('copy fe0.mp3 + fe1.mp3  c:\fendings.mp3', shell=True, )
            import time
            time.sleep(2)
            if os=="1":
                cp = subprocess.Popen('rm fe0.mp3 fe1.mp3', shell=True, )
            else:
                cp = subprocess.Popen('del fe0.mp3 fe1.mp3', shell=True, )
        output = results.output_name
        if output:
            output = output
        else:
            output = raw_input('Enter desired filename with no spaces.')
    print text
    choice = raw_input('Press 1 to create this message, or press 2 to start over')
    if choice=='1':
        xx = 1;
    elif choice=='2':
        xx=0;

#Final product making
if gender=='m':
    if os=="1":
        x = subprocess.Popen('cat intro.mp3 second.mp3 num0.mp3 num1.mp3 num2.mp3 num3.mp3 num4.mp3 num5.mp3 num6.mp3 num7.mp3 num8.mp3 num9.mp3 bridge.mp3 mreasons.mp3 vm.mp3 mendings.mp3 > %s.mp3' % output, shell=True, )
    else:
        x = subprocess.Popen('copy /b intro.mp3 + second.mp3 + num0.mp3 + num1.mp3 + num2.mp3 + num3.mp3 + num4.mp3 + num5.mp3 + num6.mp3 + num7.mp3 + num8.mp3 + num9.mp3 + bridge.mp3 + mreasons.mp3 + vm.mp3 + mendings.mp3 c:\%s.mp3' % output, shell=True, )
    import time
    time.sleep(2)
    if os=="1":
        p = subprocess.Popen('rm bridge.mp3 intro.mp3 second.mp3 num0.mp3 num1.mp3 num2.mp3 num3.mp3 num4.mp3 num5.mp3 num6.mp3 num7.mp3 num8.mp3 num9.mp3 mreasons.mp3 vm.mp3 mendings.mp3', shell=True, )
    else:
        p = subprocess.Popen('del bridge.mp3 + intro.mp3 + second.mp3 + num0.mp3 + num1.mp3 + num2.mp3 + num3.mp3 + num4.mp3 + num5.mp3 + num6.mp3 + num7.mp3 + num8.mp3 + num9.mp3 + mreasons.mp3 + vm.mp3 + mendings.mp3', shell=True, )
elif gender =='f':
    if os=="1":
        x = subprocess.Popen('cat bridge1.mp3 bridge2.mp3 > bridge.mp3', shell=True, )
    else:
        x = subprocess.Popen('copy bridge1.mp3 + bridge2.mp3 c:\ bridge.mp3', shell=True, )
    import time
    time.sleep(2)
    if os=="1":
        cp = subprocess.Popen('rm bridge1.mp3 bridge2.mp3', shell=True, )
    else:
        cp = subprocess.Popen('del bridge1.mp3 + bridge2.mp3', shell=True, )

    if os=="1":
        x = subprocess.Popen('cat intro.mp3 second.mp3 num0.mp3 num1.mp3 num2.mp3 num3.mp3 num4.mp3 num5.mp3 num6.mp3 num7.mp3 num8.mp3 num9.mp3 bridge.mp3 freasons.mp3 fendings.mp3 > %s.mp3' % output, shell=True, )
    else:
        x = subprocess.Popen('cat intro.mp3 + second.mp3 + num0.mp3 + num1.mp3 + num2.mp3 + num3.mp3 + num4.mp3 + num5.mp3 + num6.mp3 + num7.mp3 + num8.mp3 + num9.mp3 + bridge.mp3 + freasons.mp3 + fendings.mp3 c:\%s.mp3' % output, shell=True, )
    import time
    time.sleep(2)

    if os=="1":
        p = subprocess.Popen('rm bridge.mp3 intro.mp3 second.mp3 num0.mp3 num1.mp3 num2.mp3 num3.mp3 num4.mp3 num5.mp3 num6.mp3 num7.mp3 num8.mp3 num9.mp3 freasons.mp3 fendings.mp3', shell=True, )
    else:
        p = subprocess.Popen('del bridge.mp3 + intro.mp3 + second.mp3 + num0.mp3 + num1.mp3 + num2.mp3 + num3.mp3 + num4.mp3 + num5.mp3 + num6.mp3 + num7.mp3 + num8.mp3 + num9.mp3 + freasons.mp3 + fendings.mp3', shell=True, )

subprocess.call('echo %s > ~/scripty_printout.txt' % text, shell=True)
